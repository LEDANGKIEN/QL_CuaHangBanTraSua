﻿namespace GUI {
    
    
    public partial class QLCHBTRASUA {
    }
}

namespace GUI.QLCHBTRASUATableAdapters {
    partial class USP_CheckLoginTableAdapter
    {
    }
    
    
    
}
